import lib.util

def parse(config_filename):
    """Return a parsed JSON configuration file."""
    if config_filename == "" or config_filename == None:
        raise ValueError("Missing configuration filename!")
    try:
        cfg = lib.util.parse_json(
            lib.util.load_file_content(config_filename)
        )
    except Exception as ex:
        raise Exception(f"Invalid configuration file: {config_filename}\n{str(ex)}")
    return cfg
